(${input$entity}.getPassenger())
