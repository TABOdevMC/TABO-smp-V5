<#include "mcitems.ftl">
${mappedMCItemToItemStackCode(input$provideditemstack)}.set(DataComponents.ITEM_NAME, Component.literal(${input$name}));