<#include "mcitems.ftl">
${mappedMCItemToItemStackCode(input$provideditemstack)}.has(${generator.map(field$datacomponents, "datacomponents")})