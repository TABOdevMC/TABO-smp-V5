<#include "mcitems.ftl">
<#include "redwires_plugin_utils.ftl">
BlockState _block1${index} = ${mappedBlockToBlockStateCode(input$block1)};
BlockState _block2${index} = ${mappedBlockToBlockStateCode(input$block2)};
for(Property<?> property : _block1${index}.getBlock().getStateDefinition().getProperties()) {
     if (_block2${index}.hasProperty(property))
        _block2${index} = _block2${index}.setValue((Property)property, _block1${index}.getValue(property));
}