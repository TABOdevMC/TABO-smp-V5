<#include "redwires_plugin_utils.ftl">
((Object) ForgeSpawnEggItem.fromEntityType(${input$entity}.getType()) instanceof SpawnEggItem _spawnEgg${index} ? _spawnEgg${index} : Items.AIR)