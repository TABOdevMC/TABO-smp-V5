<#include "redwires_plugin_utils.ftl">
<@templateOrFallback "get_permission_level"/>
getPermissionLevel(${input$entity})