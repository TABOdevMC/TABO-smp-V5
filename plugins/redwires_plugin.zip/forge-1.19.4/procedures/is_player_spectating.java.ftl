<#include "redwires_plugin_utils.ftl">
(${input$entity} instanceof ServerPlayer _servplayerCamGet${index} && _servplayerCamGet${index}.getCamera() == ${input$sourceentity})