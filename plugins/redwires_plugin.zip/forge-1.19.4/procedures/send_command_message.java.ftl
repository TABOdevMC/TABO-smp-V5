<#include "redwires_plugin_utils.ftl">
arguments.getSource().sendSuccess(Component.literal(${input$message}), ${input$inform});