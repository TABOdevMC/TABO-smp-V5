<#include "mcitems.ftl">
{
    ItemStack _redwire$itemstack = ${mappedMCItemToItemStackCode(input$item)};
    for (Map.Entry<Enchantment, Integer> _enchantMap : _redwire$itemstack.getAllEnchantments().entrySet()) {
        String stringiterator = world.registryAccess().registryOrThrow(Registries.ENCHANTMENT).getKey(_enchantMap.getKey()).toString();
        ${statement$foreach}
    }
}