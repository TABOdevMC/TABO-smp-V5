<#assign toTarget = input$entity>
<#include "redwires_plugin_utils.ftl">
<#if toTarget == "null">
if (event instanceof LivingChangeTargetEvent _targetEvent${index})
	_targetEvent${index}.setNewTarget(null);
<#else>
if (event instanceof LivingChangeTargetEvent _targetEvent${index} && ${input$entity} instanceof LivingEntity _toTarget${index})
	_targetEvent${index}.setNewTarget(_toTarget${index});
</#if>