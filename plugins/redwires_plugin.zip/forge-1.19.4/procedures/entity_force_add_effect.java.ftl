<#include "redwires_plugin_utils.ftl">
if (${input$entity} instanceof LivingEntity _entity${index} && !_entity${index}.level.isClientSide())
	_entity${index}.forceAddEffect(new MobEffectInstance(${generator.map(field$potion, "effects")},${opt.toInt(input$duration)},${opt.toInt(input$level)}, ${input$ambient}, ${input$particles}), null);