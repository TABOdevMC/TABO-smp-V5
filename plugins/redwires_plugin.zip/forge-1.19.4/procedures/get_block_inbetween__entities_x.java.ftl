<#include "redwires_plugin_utils.ftl">
<@templateOrFallback "get_block_between_entities"/>
getBlockBetweenEntities(${input$entity}, ${input$sourceentity}).getX()