if (world.getServer()!= null)
	world.getServer().setDefaultGameType(GameType.${field$gamemode});