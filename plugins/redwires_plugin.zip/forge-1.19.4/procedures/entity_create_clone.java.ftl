<#include "redwires_plugin_utils.ftl">
<@templateOrFallback "clone_entity"/>
createClone(${input$entity}, world)