<#include "redwires_plugin_utils.ftl">
<@templateOrFallback "entity_from_string_uuid"/>
entityFromStringUUID(${input$uuidstring}, world)