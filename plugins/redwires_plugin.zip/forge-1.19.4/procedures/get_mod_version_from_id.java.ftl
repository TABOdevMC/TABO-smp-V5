<#include "redwires_plugin_utils.ftl">
<@templateOrFallback "get_mod_info"/>
getModInfo(${input$text}, 0)