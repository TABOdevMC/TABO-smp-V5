<#include "mcitems.ftl">
${mappedBlockToBlock(input$block)}.getName().getString()