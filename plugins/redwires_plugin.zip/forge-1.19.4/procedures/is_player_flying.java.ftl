<#include "redwires_plugin_utils.ftl">
(${input$entity} instanceof Player _plrFlying${index} && _plrFlying${index}.getAbilities().flying)