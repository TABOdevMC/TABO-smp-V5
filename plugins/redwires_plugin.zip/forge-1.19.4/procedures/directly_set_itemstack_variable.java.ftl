<#include "mcitems.ftl">
<#if field$VAR?contains("global:")>
Use_Remove_Copy_Statement_And_Normal_Variable_Block_Pls();
<#else>
${field$VAR?replace("local:","")} = ${mappedMCItemToItemStackCode(input$itemvalue)?replace(".copy()", "")};
</#if>