<#include "mcitems.ftl">
/*@ItemStack*/${mappedMCItemToItemStackCode(input$itemstack)?replace(".copy()", "")}