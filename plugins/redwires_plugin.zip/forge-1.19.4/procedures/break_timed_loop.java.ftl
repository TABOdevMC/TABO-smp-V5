<#if field$option == "Continue with next iteration">
_timedLoop.next();
</#if>
if (true)
	return false;