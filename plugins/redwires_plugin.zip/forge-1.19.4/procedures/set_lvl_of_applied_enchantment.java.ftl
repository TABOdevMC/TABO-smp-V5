<#include "redwires_plugin_utils.ftl">
_redwire$itemstack.getOrCreateTag().getList("Enchantments", 10).removeIf(_tag${index} -> _tag${index} instanceof CompoundTag _compound${index} && _compound${index}.getString("id").equals(stringiterator));
_redwire$itemstack.enchant(_enchantMap.getKey(), ${opt.toInt(input$enchantmentlvl)});