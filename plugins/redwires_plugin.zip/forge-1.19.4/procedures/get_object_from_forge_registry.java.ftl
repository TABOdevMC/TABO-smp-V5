for (var _entry : world.registryAccess().registryOrThrow(${generator.map(field$reg, "forgeregs")}).entrySet()) {
    ResourceLocation _regid = _entry.getKey().location();
    String _id = ${input$registryid}.replace(" ", "").toLowerCase();
    if (_regid.toString().equals(_id) || _regid.getPath().equals(_id)) {
        var _regobject = _entry.getValue();
        ${statement$stuff2do}
        break;
    }
}