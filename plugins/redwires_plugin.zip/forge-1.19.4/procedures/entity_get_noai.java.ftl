<#include "redwires_plugin_utils.ftl">
(${input$entity} instanceof Mob _mob${index} && _mob${index}.isNoAi())