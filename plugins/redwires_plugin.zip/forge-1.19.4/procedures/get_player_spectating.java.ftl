<#include "redwires_plugin_utils.ftl">
(${input$entity} instanceof ServerPlayer _servplayer${index} ? _servplayer${index}.getCamera() : null)