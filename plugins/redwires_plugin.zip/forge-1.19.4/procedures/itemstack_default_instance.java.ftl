<#include "mcitems.ftl">
/*@ItemStack*/${mappedMCItemToItem(input$provideditemstack)}.getDefaultInstance()