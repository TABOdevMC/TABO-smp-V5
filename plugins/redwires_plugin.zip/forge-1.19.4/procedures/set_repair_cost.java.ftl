<#include "mcitems.ftl">
${mappedMCItemToItemStackCode(input$provideditemstack)}.setRepairCost(${opt.toInt(input$repaircost)});