<#include "redwires_plugin_utils.ftl">
<@templateOrFallback "clone_static_entity"/>
createStaticClone(${input$entity})