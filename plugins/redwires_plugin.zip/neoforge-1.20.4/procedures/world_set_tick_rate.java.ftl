if (world.getServer() != null) {
	world.getServer().tickRateManager().setTickRate(${opt.toFloat(input$tickrate)});
} else {
	((Level) world).tickRateManager().setTickRate(${opt.toFloat(input$tickrate)});
}