<#include "redwires_plugin_utils.ftl">
((Object) SpawnEggItem.byId(${input$entity}.getType()) instanceof SpawnEggItem _spawnEgg${index} ? _spawnEgg${index} : Items.AIR)