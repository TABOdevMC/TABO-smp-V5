<#include "procedures.java.ftl">
@Mod.EventBusSubscriber
public class ${name}Procedure {
    @SubscribeEvent
    public static void onHarvestCheck(PlayerEvent.HarvestCheck event) {
        <#assign dependenciesCode><#compress>
            <@procedureDependenciesCode dependencies, {
            "x": "event.getEntity().level().clip(new ClipContext(event.getEntity().getEyePosition(1f),event.getEntity().getEyePosition(1f).add(event.getEntity().getViewVector(1f).scale(((LivingEntity) event.getEntity()).getAttribute(NeoForgeMod.BLOCK_REACH.value()).getValue())),ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, event.getEntity())).getBlockPos().getX()",
            "y": "event.getEntity().level().clip(new ClipContext(event.getEntity().getEyePosition(1f),event.getEntity().getEyePosition(1f).add(event.getEntity().getViewVector(1f).scale(((LivingEntity) event.getEntity()).getAttribute(NeoForgeMod.BLOCK_REACH.value()).getValue())),ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, event.getEntity())).getBlockPos().getY()",
            "z": "event.getEntity().level().clip(new ClipContext(event.getEntity().getEyePosition(1f),event.getEntity().getEyePosition(1f).add(event.getEntity().getViewVector(1f).scale(((LivingEntity) event.getEntity()).getAttribute(NeoForgeMod.BLOCK_REACH.value()).getValue())),ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, event.getEntity())).getBlockPos().getZ()",
            "entity": "event.getEntity()",
            "world": "event.getEntity().level()",
            "blockstate": "event.getTargetBlock()",
            "canHarvest": "event.canHarvest()",
            "event": "event"
            }/>
        </#compress></#assign>
        execute(event<#if dependenciesCode?has_content>,</#if>${dependenciesCode});
    }