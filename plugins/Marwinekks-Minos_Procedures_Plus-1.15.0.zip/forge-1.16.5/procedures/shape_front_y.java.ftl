(${input$entity}.getY() + ${input$entity}.getEyeHeight() + ${input$entity}.getLookAngle().y * ${input$distance}) + i
