private static CompoundTag getOrCreateCustomData(ItemStack itemstack) {
    if (!itemstack.has(DataComponents.CUSTOM_DATA))
        itemstack.set(DataComponents.CUSTOM_DATA, CustomData.of(new CompoundTag()));
    return itemstack.get(DataComponents.CUSTOM_DATA).getUnsafe();
}