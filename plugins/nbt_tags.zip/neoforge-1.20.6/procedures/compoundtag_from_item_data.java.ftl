<#include "mcitems.ftl">
<#include "nbt_tags_utils.ftl">
<@templateOrFallback "itemstack_get_custom_data"/>
getOrCreateCustomData(${mappedMCItemToItemStackCode(input$item)})