<#include "mcitems.ftl">
((CompoundTag) ${mappedMCItemToItemStackCode(input$item)}.saveOptional(world.registryAccess()))