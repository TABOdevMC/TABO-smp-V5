<#include "mcitems.ftl">
${mappedMCItemToItemStackCode(input$item)}.getOrCreateTag()