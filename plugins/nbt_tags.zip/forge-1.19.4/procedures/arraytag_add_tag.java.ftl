<#include "nbt_tags_utils.ftl">
<#assign tagType = field$tagtype?replace("Array", "")>
if ((Tag) ${input$value} instanceof NumericTag _numberTag${index})
    ${input$arraytag}.add(${tagType}.valueOf(_numberTag${index}.getAs${tagType?replace("Tag", "")}()));