<#include "nbt_tags_utils.ftl">
((Tag) ${input$tag} instanceof StringTag _stringTag${index} ? _stringTag${index}.getAsString() : ${input$default})