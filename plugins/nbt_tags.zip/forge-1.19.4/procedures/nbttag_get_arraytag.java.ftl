<#include "nbt_tags_utils.ftl">
((Tag) ${input$tag} instanceof ${field$tagtype} _array${index} ? _array${index} : new ${field$tagtype}(new ${field$tagtype?lower_case?replace("arraytag", "")}[0]))