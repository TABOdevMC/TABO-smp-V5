<#assign tagType = field$tagtype>
<#if tagType == "no">
${input$compoundtag}.contains(${input$tagname})
<#else>
(${input$compoundtag}.get(${input$tagname}) instanceof ${tagType})
</#if>