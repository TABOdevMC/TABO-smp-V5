<#assign value = input$value>
<#assign shouldCopy = value[0..3] != "new " && !value?contains("Tag.valueOf(")>
${input$listtag}.add(${value}<#if shouldCopy>.copy()</#if>);