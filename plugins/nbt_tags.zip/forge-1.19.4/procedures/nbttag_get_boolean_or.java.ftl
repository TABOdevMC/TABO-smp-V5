<#include "nbt_tags_utils.ftl">
((Tag) ${input$tag} instanceof ByteTag _byteTag${index} ? _byteTag${index}.getAsByte() == (byte) 1 : ${input$default})