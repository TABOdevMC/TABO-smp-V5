private static CompoundTag saveWithId(Entity entity) {
    CompoundTag data = entity.saveWithoutId(new CompoundTag());
    String id = entity.getEncodeId();
    if (id != null)
        data.putString("id", id);
    return data;
}