<#assign tagType = field$tagtype?replace("ArrayTag", "")>
for (${tagType?lower_case} numberiterator: ${input$arraytag}.getAs${tagType}Array()) {
    ${statement$foreach}
}