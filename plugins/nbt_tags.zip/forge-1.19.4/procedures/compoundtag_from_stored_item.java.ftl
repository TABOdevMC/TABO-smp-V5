<#include "mcitems.ftl">
${mappedMCItemToItemStackCode(input$item)}.save(new CompoundTag())