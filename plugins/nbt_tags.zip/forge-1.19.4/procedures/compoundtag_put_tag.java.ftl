<#assign value = input$value>
<#assign shouldCopy = value[0..3] != "new " && !value?contains("Tag.valueOf(")>
${input$compoundtag}.put(${input$tagname}, ${value}<#if shouldCopy>.copy()</#if>);