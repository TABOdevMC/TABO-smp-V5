<#include "nbt_tags_utils.ftl">
BlockPos _blockPos${index} = BlockPos.containing(${opt.toInt(input$x)}, ${opt.toInt(input$y)}, ${opt.toInt(input$z)});
BlockState _blockState${index} = world.getBlockState(_blockPos${index});
((Level) world).sendBlockUpdated(_blockPos${index}, _blockState${index}, _blockState${index}, 3);