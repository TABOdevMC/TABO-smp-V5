<#include "nbt_tags_utils.ftl">
((Tag) ${input$tag} instanceof CompoundTag _compound${index} ? _compound${index} : new CompoundTag())