<#include "nbt_tags_utils.ftl">
CompoundTag _toIterate${index} = ${input$compoundtag}.copy();
for (String stringiterator : _toIterate${index}.getAllKeys()) {
    Tag tagiterator = _toIterate${index}.get(stringiterator);
    ${statement$foreach}
}
