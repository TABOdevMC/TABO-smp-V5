for (Tag tagiterator: ${input$listtag}.copy()) {
    ${statement$foreach}
}