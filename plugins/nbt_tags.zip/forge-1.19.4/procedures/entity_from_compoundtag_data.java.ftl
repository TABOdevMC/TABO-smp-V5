<#include "nbt_tags_utils.ftl">
<@templateOrFallback "entity_from_compoundtag"/>
spawnEntityFromCompoundTag(${input$compoundtag}, world, ${field$randomize_uuid?lower_case})