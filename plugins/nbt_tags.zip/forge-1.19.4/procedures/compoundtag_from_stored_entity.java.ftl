<#include "nbt_tags_utils.ftl">
<@templateOrFallback "entity_save_with_id"/>
saveWithId(${input$entity})