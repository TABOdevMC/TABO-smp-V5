<#if !(head)??>
<#assign capability = "_CAPABILITY">
<#else>
<#assign capability = "">
</#if>
entity.getCapability(${JavaModName}Variables.PLAYER_VARIABLES${capability}).orElseGet(${JavaModName}Variables.PlayerVariables::new).serializeNBT()