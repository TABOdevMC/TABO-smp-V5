<#include "nbt_tags_utils.ftl">
if ((Object) world.getBlockEntity(BlockPos.containing(${opt.toInt(input$x)}, ${opt.toInt(input$y)}, ${opt.toInt(input$z)})) instanceof BlockEntity _blockEnt${index})
    _blockEnt${index}.load(${input$compoundtag});