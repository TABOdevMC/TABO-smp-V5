<#include "nbt_tags_utils.ftl">
((Tag) ${input$tag} instanceof ListTag _list${index} ? _list${index} : new ListTag())