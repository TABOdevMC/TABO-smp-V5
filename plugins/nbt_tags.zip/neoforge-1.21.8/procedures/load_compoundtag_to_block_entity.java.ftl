<#include "nbt_tags_utils.ftl">
if (world.getBlockEntity(BlockPos.containing(${opt.toInt(input$x)}, ${opt.toInt(input$y)}, ${opt.toInt(input$z)})) instanceof BlockEntity _blockEnt${index})
    _blockEnt${index}.loadWithComponents(TagValueInput.create(ProblemReporter.DISCARDING, world.registryAccess(), ${input$compoundtag}));