<#include "nbt_tags_utils.ftl">
((Tag) ${input$tag} instanceof ByteTag _byteTag${index} ? _byteTag${index}.byteValue() == (byte) 1 : ${input$default})