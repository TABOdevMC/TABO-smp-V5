<@head>{
${field$tagtype} _arrayTagToAdd = ${input$arraytag};</@head>
_arrayTagToAdd.addTag(_arrayTagToAdd.size(), ${input$value});
<@tail>}</@tail>