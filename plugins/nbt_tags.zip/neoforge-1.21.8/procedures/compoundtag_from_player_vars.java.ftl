<@addTemplate file="utils/get_player_vars_snapshot.java.ftl"/>
getPlayerVarsSnapshot(${input$entity}, world)