<#include "nbt_tags_utils.ftl">
Entity _toLoad${index} = ${input$entity};
_toLoad${index}.load(TagValueInput.create(ProblemReporter.DISCARDING, _toLoad${index}.level().registryAccess(), ${input$compoundtag}));