<#include "mcitems.ftl">
<#include "nbt_tags_utils.ftl">
ItemStack.OPTIONAL_CODEC.encodeStart(NbtOps.INSTANCE, ${mappedMCItemToItemStackCode(input$item)}).result().map(_tag${index} -> (CompoundTag) _tag${index}).orElseGet(CompoundTag::new)