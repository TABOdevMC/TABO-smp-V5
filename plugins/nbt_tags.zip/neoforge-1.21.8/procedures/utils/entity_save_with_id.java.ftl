private static CompoundTag saveWithId(Entity entity) {
    TagValueOutput output = TagValueOutput.createWithContext(ProblemReporter.DISCARDING, entity.level().registryAccess());
    entity.saveWithoutId(output);
    CompoundTag data = output.buildResult();
    String id = entity.getEncodeId();
    if (id != null)
        data.putString("id", id);
    return data;
}