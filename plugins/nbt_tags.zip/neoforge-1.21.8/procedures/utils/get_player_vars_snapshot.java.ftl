private static CompoundTag getPlayerVarsSnapshot(Entity entity, LevelAccessor level) {
    TagValueOutput output = TagValueOutput.createWithContext(ProblemReporter.DISCARDING, level.registryAccess());
    entity.getData(${JavaModName}Variables.PLAYER_VARIABLES).serialize(output);
    return output.buildResult();
}