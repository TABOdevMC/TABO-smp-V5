Blockly.Msg["COMPOUNDTAG_HUE"] = "45";
Blockly.Msg["TAG_HUE"] = "#007F15";
Blockly.Msg["LISTTAG_HUE"] = "#23468C";
Blockly.Msg["ARRAYTAG_HUE"] = "#007250";

Blockly.Blocks['nbttag_arraytag_builder_container'] = {
    init: function () {
        this.appendDummyInput().appendField(javabridge.t('blockly.nbttag_arraytag_builder.container'));
        this.appendStatementInput('STACK');
        this.contextMenu = false;
        this.setColour("%{BKY_ARRAYTAG_HUE}");
    }
};

Blockly.Blocks['nbttag_arraytag_builder_input'] = {
    init: function () {
        this.appendDummyInput().appendField(javabridge.t('blockly.nbttag_arraytag_builder.input'));
        this.setPreviousStatement(true);
        this.setNextStatement(true);
        this.contextMenu = false;
        this.fieldValues_ = [];
        this.setColour("%{BKY_ARRAYTAG_HUE}");
    }
};

Blockly.Extensions.registerMutator('nbttag_arraytag_builder', simpleRepeatingInputMixin(
        'nbttag_arraytag_builder_container', 'nbttag_arraytag_builder_input', 'numbers',
        function(thisBlock, inputName, index) {
            const ALIGN_RIGHT = Blockly.ALIGN_RIGHT ?? Blockly.Input.Align.RIGHT;
            thisBlock.appendValueInput(inputName + index).setCheck("Number").setAlign(ALIGN_RIGHT);
        }),
    undefined, ['nbttag_arraytag_builder_input']);