private static Entity spawnEntityFromCompoundTag(CompoundTag data, LevelAccessor world, boolean randomizeUUID) {
    if (world instanceof ServerLevel server) {
        Entity toSpawn = EntityType.create(data, server, EntitySpawnReason.NATURAL).orElse(null);
        if (toSpawn != null) {
            if (randomizeUUID)
                toSpawn.setUUID(UUID.randomUUID());
            server.addFreshEntity(toSpawn);
            return toSpawn;
        }
    }
    return null;
}