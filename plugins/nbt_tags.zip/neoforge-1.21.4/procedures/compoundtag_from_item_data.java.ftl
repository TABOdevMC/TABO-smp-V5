<#include "mcitems.ftl">
<@addTemplate file="utils/itemstack_get_custom_data.java.ftl"/>
getOrCreateCustomData(${mappedMCItemToItemStackCode(input$item)})