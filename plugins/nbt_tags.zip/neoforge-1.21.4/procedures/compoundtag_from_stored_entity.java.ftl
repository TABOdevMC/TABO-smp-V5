<@addTemplate file="utils/entity_save_with_id.java.ftl"/>
saveWithId(${input$entity})