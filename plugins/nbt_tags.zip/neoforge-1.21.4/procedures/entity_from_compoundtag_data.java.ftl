<@addTemplate file="utils/entity_from_compoundtag.java.ftl"/>
spawnEntityFromCompoundTag(${input$compoundtag}, world, ${field$randomize_uuid?lower_case})