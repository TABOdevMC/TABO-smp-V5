<#include "mcitems.ftl">
NbtUtils.writeBlockState(${mappedBlockToBlockStateCode(input$blockstate)}).toString()