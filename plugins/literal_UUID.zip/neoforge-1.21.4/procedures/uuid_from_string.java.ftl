<@addTemplate file="utils/try_or_default.java.ftl"/>
tryOrDefault(${input$string}, UUID::fromString, () -> new UUID(0, 0))