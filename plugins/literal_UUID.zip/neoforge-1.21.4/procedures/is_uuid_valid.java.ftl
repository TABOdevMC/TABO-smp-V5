<@addTemplate file="utils/try_run.java.ftl"/>
tryRun(${input$uuid}, UUID::fromString)