<#include "literal_uuid_utils.ftl">
<@templateOrFallback "try_or_default"/>
tryOrDefault(${input$string}, UUID::fromString, () -> new UUID(0, 0))