<#include "mcitems.ftl">
${mappedMCItemToItemStackCode(input$itemstack)}.getOrCreateTag().putUUID(${input$tagname}, ${input$uuid});