<#include "mcitems.ftl">
${mappedMCItemToItemStackCode(input$itemstack)}.getOrCreateTag().hasUUID(${input$tagname})