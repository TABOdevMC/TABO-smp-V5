<#include "literal_uuid_utils.ftl">
<@templateOrFallback "try_run"/>
tryRun(${input$uuid}, UUID::fromString)