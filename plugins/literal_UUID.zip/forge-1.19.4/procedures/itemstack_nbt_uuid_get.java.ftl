<#include "mcitems.ftl">
${mappedMCItemToItemStackCode(input$itemstack)}.getOrCreateTag().getUUID(${input$tagname})