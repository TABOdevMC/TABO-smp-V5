<#include "literal_uuid_utils.ftl">
BlockEntity _blockEntity${index} = world.getBlockEntity(BlockPos.containing(${opt.toInt(input$x)}, ${opt.toInt(input$y)}, ${opt.toInt(input$z)}));
if (_blockEntity${index} != null)
    _blockEntity${index}.getPersistentData().put(${input$tagName}, new IntArrayTag(UUIDUtil.uuidToIntArray(${input$uuid})));