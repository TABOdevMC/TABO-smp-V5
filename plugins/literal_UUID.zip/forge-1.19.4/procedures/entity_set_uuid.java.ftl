<#include "literal_uuid_utils.ftl">
Entity _ent${index} = ${input$entity};
if (!(_ent${index} instanceof Player) && !_ent${index}.level.isClientSide())
    _ent${index}.setUUID(${input$uuid});