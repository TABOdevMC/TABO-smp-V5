private static <A, B> A tryOrDefault(B funcArg, FailableFunction<B, A, Exception> func, Supplier<A> fallback) {
    try {
        return func.apply(funcArg);
    } catch (Exception e) {
        return fallback.get();
    }
}