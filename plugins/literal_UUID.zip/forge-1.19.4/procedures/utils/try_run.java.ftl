private static <T> boolean tryRun(T consArg, FailableConsumer<T, Exception> consumer) {
    try {
        consumer.accept(consArg);
        return true;
    } catch (Exception e) {
        return false;
    }
}