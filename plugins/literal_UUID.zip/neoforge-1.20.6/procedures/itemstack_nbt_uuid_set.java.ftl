<#include "mcitems.ftl">
<#include "literal_uuid_utils.ftl">
final String _tagName${index} = ${input$tagname};
final UUID _tagValue${index} = ${input$uuid};
CustomData.update(DataComponents.CUSTOM_DATA, ${mappedMCItemToItemStackCode(input$itemstack)}, _tag -> _tag.put(_tagName${index}, new IntArrayTag(UUIDUtil.uuidToIntArray(_tagValue${index}))));