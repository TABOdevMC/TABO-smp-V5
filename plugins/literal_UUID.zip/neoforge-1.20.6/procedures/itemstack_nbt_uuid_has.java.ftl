<#include "mcitems.ftl">
${mappedMCItemToItemStackCode(input$itemstack)}.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().hasUUID(${input$tagname})