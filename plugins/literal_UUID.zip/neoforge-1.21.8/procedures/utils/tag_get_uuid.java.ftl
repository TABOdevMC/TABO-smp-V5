private static UUID tagGetUUID(Tag tag) {
	if (tag == null)
		throw new IllegalArgumentException("Cannot get UUID from null tag \"net.minecraft.nbt.Tag\"");
	if (tag instanceof IntArrayTag arr) {
        if (arr.size() != 4) {
            throw new IllegalArgumentException(String.format("Expected UUID-Array to be of length 4, but found %s.", arr.size()));
        } else {
            return UUIDUtil.uuidFromIntArray(arr.getAsIntArray());
        }
	} else {
        throw new IllegalArgumentException(String.format("Expected UUID-Tag to be of type %s, but found %s.", IntArrayTag.TYPE.getName(), tag.getType().getName()));
	}
}