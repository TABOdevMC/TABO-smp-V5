<@addTemplate file="utils/tag_get_uuid.java.ftl"/>
<#include "literal_uuid_utils.ftl">
(world.getBlockEntity(BlockPos.containing(${opt.toInt(input$x)}, ${opt.toInt(input$y)}, ${opt.toInt(input$z)})) instanceof BlockEntity _blockEnt${index} ? tagGetUUID(_blockEnt${index}.getPersistentData().get(${input$tagName})) : new UUID(0, 0))