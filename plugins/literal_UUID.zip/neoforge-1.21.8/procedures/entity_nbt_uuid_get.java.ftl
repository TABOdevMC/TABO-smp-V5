<@addTemplate file="utils/tag_get_uuid.java.ftl"/>
tagGetUUID(${input$entity}.getPersistentData().get(${input$tagname}))