<#include "literal_uuid_utils.ftl">
(${input$entity}.getPersistentData().get(${input$tagname}) instanceof IntArrayTag _arr${index} && _arr${index}.size() == 4)