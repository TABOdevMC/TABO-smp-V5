<#include "mcitems.ftl">
<@addTemplate file="utils/tag_get_uuid.java.ftl"/>
tagGetUUID(${mappedMCItemToItemStackCode(input$itemstack)}.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().get(${input$tagname}))