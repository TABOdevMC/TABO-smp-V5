<#include "mcitems.ftl">
<#include "literal_uuid_utils.ftl">
(${mappedMCItemToItemStackCode(input$itemstack)}.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().get(${input$tagname}) instanceof IntArrayTag _arr${index} && _arr${index}.size() == 4)