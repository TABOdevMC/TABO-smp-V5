<#include "mutable_components_utils.ftl">
((Object) ${input$component}.getStyle().getClickEvent() instanceof ClickEvent _click${index} ? _click${index}.getValue() : "")