<#include "mutable_components_utils.ftl">
if (${input$component}.getContents() instanceof TranslatableContents _tc${index}) {
    for (Object _translationArg : _tc${index}.getArgs()) {
        ${statement$foreach}
    }
}