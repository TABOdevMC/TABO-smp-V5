<#include "mcitems.ftl">
(${mappedMCItemToItemStackCode(input$book)}.getOrCreateTag().get("pages") instanceof ListTag)