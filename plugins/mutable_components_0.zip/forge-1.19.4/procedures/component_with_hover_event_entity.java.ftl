<#include "mutable_components_utils.ftl">
<@templateOrFallback "with_hover_event_entity"/>
withHoverEvent(${input$component}, ${input$entity})