<#include "mutable_components_utils.ftl">
<@templateOrFallback "with_click_event"/>
withClickEvent(${input$component}, ClickEvent.Action.${field$clicktype}, ${input$txt})