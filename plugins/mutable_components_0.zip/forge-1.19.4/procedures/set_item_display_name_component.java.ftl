<#include "mcitems.ftl">
${mappedMCItemToItemStackCode(input$provideditemstack)}.setHoverName(${input$component});