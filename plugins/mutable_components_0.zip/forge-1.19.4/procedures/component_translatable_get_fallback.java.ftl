<#include "mutable_components_utils.ftl">
(${input$component}.getContents() instanceof TranslatableContents _tc${index} && _tc${index}.getFallback() != null ? _tc${index}.getFallback() : "")