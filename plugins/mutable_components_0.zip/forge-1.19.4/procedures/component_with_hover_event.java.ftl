<#include "mutable_components_utils.ftl">
<@templateOrFallback "with_hover_event_component"/>
withHoverEvent(${input$component}, ${input$comp2})