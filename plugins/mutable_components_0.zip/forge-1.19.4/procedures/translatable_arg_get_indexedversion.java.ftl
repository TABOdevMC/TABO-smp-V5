<#assign castType = field$argtype>
((${castType}) ((TranslatableContents) ${input$component}.getContents()).getArgs()[${opt.toInt(input$argnum)}])<#if castType == "Number">.doubleValue()</#if>