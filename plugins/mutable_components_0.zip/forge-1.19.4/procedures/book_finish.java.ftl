<#include "mcitems.ftl">
<#include "mutable_components_utils.ftl">
CompoundTag _itemData${index} = ${mappedMCItemToItemStackCode(input$book)}.getOrCreateTag();
_itemData${index}.putString("title", ${input$title});
_itemData${index}.putString("author", ${input$author});
_itemData${index}.putInt("generation", Math.min(3, Math.max(${opt.toInt(input$generation)}, 0)));
_itemData${index}.put("pages", _bookContents);