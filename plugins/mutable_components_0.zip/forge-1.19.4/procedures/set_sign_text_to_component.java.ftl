<#include "mutable_components_utils.ftl">
if (((Level)world).getBlockEntity(BlockPos.containing(${input$x},${input$y},${input$z})) instanceof SignBlockEntity _sign${index})
	_sign${index}.setMessage(Math.min(3, Math.max(${input$line}, 0)), ${input$component});