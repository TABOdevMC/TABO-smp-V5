{
    ListTag _bookContents = new ListTag();
    ${statement$bookcreation}
}
