<#include "mutable_components_utils.ftl">
<@templateOrFallback "entity_command_result_component", "custom_command_source"/>
getEntityCommandResult(${input$entity}, ${input$command})