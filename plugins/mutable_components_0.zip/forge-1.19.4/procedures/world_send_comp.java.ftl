if (!world.isClientSide() && world.getServer() != null) {
	world.getServer().getPlayerList().broadcastSystemMessage(${input$component}, false);
}