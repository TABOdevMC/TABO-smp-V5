<#include "mutable_components_utils.ftl">
<@templateOrFallback "world_command_result_component", "custom_command_source"/>
getWorldCommandResult(world, new Vec3(${input$x}, ${input$y}, ${input$z}), ${input$command})