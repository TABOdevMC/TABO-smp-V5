<#include "mutable_components_utils.ftl">
for (Component _comp${index} : ${input$component}.getSiblings()) {
	MutableComponent componentiterator = (MutableComponent) _comp${index};
	${statement$foreach}
}