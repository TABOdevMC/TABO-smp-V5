<#include "mutable_components_utils.ftl">
(event instanceof ServerChatEvent _serverChat${index} ? (MutableComponent) _serverChat${index}.getMessage() : Component.empty())