<#include "mutable_components_utils.ftl">
((Object) ${input$component}.getStyle().getColor() instanceof TextColor _txtColor${index} ? _txtColor${index}.getValue() : 0xFFFFFF)