<#include "mcitems.ftl">
<#include "mutable_components_utils.ftl">
for (Tag _tag${index} : (ListTag) ${mappedMCItemToItemStackCode(input$book)}.getOrCreateTag().get("pages")) {
    MutableComponent componentiterator = Component.Serializer.fromJson(_tag${index} instanceof StringTag _stringTag${index} ? _stringTag${index}.getAsString() : "\"\"");
    ${statement$foreach}
}