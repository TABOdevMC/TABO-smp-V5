<#include "mcitems.ftl">
<#include "mutable_components_utils.ftl">
<@templateOrFallback "with_hover_event_item"/>
withHoverEvent(${input$component}, ${mappedMCItemToItemStackCode(input$provideditemstack)})