<#include "mutable_components_utils.ftl">
<@templateOrFallback "try_or_default"/>
tryOrDefault(${input$txt}, Component.Serializer::fromJson, Component::empty)