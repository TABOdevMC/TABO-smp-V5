<#include "mutable_components_utils.ftl">
(${input$component}.getContents() instanceof TranslatableContents _tc${index} ? _tc${index}.getKey() : "")