<#include "mcitems.ftl">
<#if (field$removebrackets!"FALSE") == "FALSE">
((MutableComponent) (${mappedMCItemToItemStackCode(input$provideditemstack, 1)}.getDisplayName()))
<#else>
((MutableComponent) ((TranslatableContents) ${mappedMCItemToItemStackCode(input$provideditemstack, 1)}.getDisplayName().getContents()).getArgs()[0])
</#if>