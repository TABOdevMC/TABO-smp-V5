<#assign castType = field$argtype>
((${castType}) _translationArg)<#if castType == "Number">.doubleValue()</#if>