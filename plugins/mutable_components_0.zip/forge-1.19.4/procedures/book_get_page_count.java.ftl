<#include "mcitems.ftl">
<#include "mutable_components_utils.ftl">
(${mappedMCItemToItemStackCode(input$book)}.getOrCreateTag().get("pages") instanceof ListTag _listTag${index} ? _listTag${index}.size() : -1)