<#include "mutable_components_utils.ftl">
if (event instanceof ServerChatEvent _serverChat${index})
	_serverChat${index}.setMessage(${input$component});