<#include "mutable_components_utils.ftl">
<@templateOrFallback "component_with_color"/>
componentWithColor(${input$component}, ${opt.toInt(input$rgb)})