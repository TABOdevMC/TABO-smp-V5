private static CommandSource customCommandSource(MutableComponent msgGetter) {
    return new CommandSource() {
        @Override
        public void sendSystemMessage(Component message) {
            msgGetter.append(message);
        }

        @Override
        public boolean acceptsSuccess() {
            return true;
        }

        @Override
        public boolean acceptsFailure() {
            return true;
        }

        @Override
        public boolean shouldInformAdmins() {
            return false;
        }
    };
}