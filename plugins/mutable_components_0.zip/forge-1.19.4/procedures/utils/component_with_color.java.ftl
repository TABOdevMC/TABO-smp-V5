private static MutableComponent componentWithColor(MutableComponent comp, int value) {
    return comp.withStyle(_style -> _style.withColor(value));
}