private static MutableComponent withClickEvent(MutableComponent comp, ClickEvent.Action type, String value) {
    return comp.withStyle(_style -> _style.withClickEvent(new ClickEvent(type, value)));
}