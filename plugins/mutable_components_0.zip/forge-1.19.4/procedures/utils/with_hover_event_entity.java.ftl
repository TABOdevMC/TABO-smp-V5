private static MutableComponent withHoverEvent(MutableComponent comp, Entity ent) {
    return comp.withStyle(_style -> _style.withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_ENTITY,
    new HoverEvent.EntityTooltipInfo(ent.getType(), ent.getUUID(), ent.getDisplayName()))));
}