private static MutableComponent withHoverEvent(MutableComponent comp, MutableComponent value) {
    return comp.withStyle(_style -> _style.withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, value)));
}