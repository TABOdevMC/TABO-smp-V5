private static MutableComponent getWorldCommandResult(LevelAccessor world, Vec3 pos, String cmd) {
    MutableComponent result = Component.empty();
    if (world instanceof ServerLevel level)
        level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(customCommandSource(result), pos, Vec2.ZERO, level, 4,
        "", Component.literal(""), level.getServer(), null), cmd);
    List<Component> siblings = result.getSiblings();
    return !siblings.isEmpty() ? (MutableComponent) siblings.get(0) : Component.empty();
}