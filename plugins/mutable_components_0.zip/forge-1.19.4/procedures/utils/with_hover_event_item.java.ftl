private static MutableComponent withHoverEvent(MutableComponent comp, ItemStack value) {
    return comp.withStyle(_style -> _style.withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_ITEM, new HoverEvent.ItemStackInfo(value))));
}