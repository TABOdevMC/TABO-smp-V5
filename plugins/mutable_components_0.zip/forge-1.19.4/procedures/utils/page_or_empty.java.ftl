private static MutableComponent getPageOrEmpty(ItemStack item, int pageIndex) {
    try {
        return (MutableComponent) item.get(DataComponents.WRITTEN_BOOK_CONTENT).pages().get(Math.clamp(pageIndex, 0, 99)).raw();
    } catch (Exception e) {
        return Component.empty();
    }
}