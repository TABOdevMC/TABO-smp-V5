private static MutableComponent getEntityCommandResult(Entity entity, String cmd) {
    MutableComponent result = Component.empty();
    if(!entity.level().isClientSide() && entity.getServer() != null)
        entity.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
                customCommandSource(result), entity.position(), entity.getRotationVector(),
                entity.level() instanceof ServerLevel ? (ServerLevel) entity.level() : null, 4,
                entity.getName().getString(), entity.getDisplayName(), entity.level().getServer(), entity
        ), cmd);
    List<Component> siblings = result.getSiblings();
    return !siblings.isEmpty() ? (MutableComponent) siblings.get(0) : Component.empty();
}