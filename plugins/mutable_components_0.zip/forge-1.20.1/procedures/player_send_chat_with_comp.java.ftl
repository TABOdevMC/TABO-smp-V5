<#include "mutable_components_utils.ftl">
if (${input$entity} instanceof Player _player${index} && !_player${index}.level().isClientSide())
	_player${index}.displayClientMessage(${input$component}, ${input$actbar});