{
    final MutableComponent _success =${input$component};
    arguments.getSource().sendSuccess(() -> _success, ${input$inform});
}