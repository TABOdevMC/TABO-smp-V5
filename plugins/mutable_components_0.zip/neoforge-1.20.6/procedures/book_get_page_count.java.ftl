<#include "mcitems.ftl">
<#include "mutable_components_utils.ftl">
(${mappedMCItemToItemStackCode(input$book)}.get(DataComponents.WRITTEN_BOOK_CONTENT) instanceof WrittenBookContent _wbc${index} ? _wbc${index}.pages().size() : -1)