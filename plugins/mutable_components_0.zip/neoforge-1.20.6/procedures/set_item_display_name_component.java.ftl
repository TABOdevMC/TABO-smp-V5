<#include "mcitems.ftl">
${mappedMCItemToItemStackCode(input$provideditemstack)}.set(DataComponents.CUSTOM_NAME, ${input$component});