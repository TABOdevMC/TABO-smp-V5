<#include "mcitems.ftl">
${mappedMCItemToItemStackCode(input$book)}.has(DataComponents.WRITTEN_BOOK_CONTENT)