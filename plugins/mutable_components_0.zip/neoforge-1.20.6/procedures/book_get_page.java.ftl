<#include "mcitems.ftl">
<#include "mutable_components_utils.ftl">
<@templateOrFallback "page_or_empty"/>
getPageOrEmpty(${mappedMCItemToItemStackCode(input$book)}, ${opt.toInt(input$pagenum)})