<#include "mutable_components_utils.ftl">
<@templateOrFallback "try_or_default"/>
((MutableComponent) tryOrDefault(${input$txt}, _txt${index} -> ComponentSerialization.CODEC.parse(JsonOps.INSTANCE, com.google.gson.JsonParser.parseString(_txt${index})).getOrThrow(), Component::empty))