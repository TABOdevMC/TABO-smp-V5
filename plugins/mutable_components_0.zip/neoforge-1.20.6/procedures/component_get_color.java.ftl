<#include "mutable_components_utils.ftl">
(${input$component}.getStyle().getColor() instanceof TextColor _txtColor${index} ? _txtColor${index}.getValue() : 0xFFFFFF)