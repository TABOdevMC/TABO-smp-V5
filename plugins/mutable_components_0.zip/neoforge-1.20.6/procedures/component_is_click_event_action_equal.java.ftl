<#include "mutable_components_utils.ftl">
(${input$component}.getStyle().getClickEvent() instanceof ClickEvent _click${index} && _click${index}.getAction() == ClickEvent.Action.${field$clicktype})