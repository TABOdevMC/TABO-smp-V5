{
    List<Filterable<Component>> _bookContents = new ArrayList<>();
    ${statement$bookcreation}
}
