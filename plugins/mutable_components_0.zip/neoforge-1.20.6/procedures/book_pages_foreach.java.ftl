<#include "mcitems.ftl">
<#include "mutable_components_utils.ftl">
for (Filterable<Component> _filteredComp${index} : ${mappedMCItemToItemStackCode(input$book)}.get(DataComponents.WRITTEN_BOOK_CONTENT).pages()) {
    MutableComponent componentiterator = (MutableComponent) _filteredComp${index}.raw();
    ${statement$foreach}
}