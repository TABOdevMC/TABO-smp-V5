<#include "mutable_components_utils.ftl">
(${input$component}.getStyle().getHoverEvent() instanceof HoverEvent _hover${index} && _hover${index}.getAction() == HoverEvent.Action.${field$hovertype})