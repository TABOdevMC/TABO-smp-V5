<#include "mutable_components_utils.ftl">
final MutableComponent _success${index} = ${input$component};
arguments.getSource().sendSuccess(() -> _success${index}, ${input$inform});