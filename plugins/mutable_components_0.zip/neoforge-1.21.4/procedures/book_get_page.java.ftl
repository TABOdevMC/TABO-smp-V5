<#include "mcitems.ftl">
<@addTemplate file="utils/page_or_empty.java.ftl"/>
getPageOrEmpty(${mappedMCItemToItemStackCode(input$book)}, ${opt.toInt(input$pagenum)})