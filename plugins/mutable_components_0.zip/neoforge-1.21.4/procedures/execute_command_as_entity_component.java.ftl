<@addTemplate file="utils/entity_command_result_component.java.ftl"/>
<@addTemplate file="utils/custom_command_source.java.ftl"/>
getEntityCommandResult(${input$entity}, ${input$command})