<@addTemplate file="utils/with_hover_event_component.java.ftl"/>
withHoverEvent(${input$component}, ${input$comp2})