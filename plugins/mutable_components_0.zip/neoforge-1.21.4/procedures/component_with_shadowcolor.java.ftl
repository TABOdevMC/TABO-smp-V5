<@addTemplate file="utils/shadowcolor.java.ftl"/>
withShadowColor(${input$component}, ${opt.toInt(input$rgb)})