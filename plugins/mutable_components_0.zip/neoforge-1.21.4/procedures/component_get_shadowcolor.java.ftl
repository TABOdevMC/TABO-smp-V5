<#include "mutable_components_utils.ftl">
(${input$component}.getStyle().getShadowColor() instanceof Integer _shadowColor${index} ? _shadowColor${index} : 0)