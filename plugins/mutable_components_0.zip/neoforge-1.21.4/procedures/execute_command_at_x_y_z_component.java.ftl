<@addTemplate file="utils/world_command_result_component.java.ftl"/>
<@addTemplate file="utils/custom_command_source.java.ftl"/>
getWorldCommandResult(world, new Vec3(${input$x}, ${input$y}, ${input$z}), ${input$command})