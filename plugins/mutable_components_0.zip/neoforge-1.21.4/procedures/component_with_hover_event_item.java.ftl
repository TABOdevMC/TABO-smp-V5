<#include "mcitems.ftl">
<@addTemplate file="utils/with_hover_event_item.java.ftl"/>
withHoverEvent(${input$component}, ${mappedMCItemToItemStackCode(input$provideditemstack)})