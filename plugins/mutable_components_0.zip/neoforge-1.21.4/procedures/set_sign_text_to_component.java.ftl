<#include "mutable_components_utils.ftl">
if (((Level)world).getBlockEntity(BlockPos.containing(${input$x},${input$y},${input$z})) instanceof SignBlockEntity _sign${index})
	_sign${index}.setText(_sign${index}.getText(${input$editfront}).setMessage(Math.clamp(${opt.toInt(input$line)},0,3), ${input$component}),${input$editfront});