<@addTemplate file="utils/with_hover_event_entity.java.ftl"/>
withHoverEvent(${input$component}, ${input$entity})