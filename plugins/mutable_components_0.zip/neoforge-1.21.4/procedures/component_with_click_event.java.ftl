<@addTemplate file="utils/with_click_event.java.ftl"/>
withClickEvent(${input$component}, ClickEvent.Action.${field$clicktype}, ${input$txt})