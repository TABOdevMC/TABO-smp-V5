Blockly.Msg['COMPONENT_HUE'] = '135';

Blockly.Blocks['mutablecomponent_append_mutator_container'] = {
    init: function () {
        this.appendDummyInput().appendField(javabridge.t('blockly.mutablecomponent_append_mutator.container'));
        this.appendStatementInput('STACK');
        this.contextMenu = false;
        this.setColour(135);
    }
};

Blockly.Blocks['mutablecomponents_translatable_container'] = {
    init: function () {
        this.appendDummyInput().appendField(javabridge.t('blockly.translatable_component_mutator.container'));
        this.appendStatementInput('STACK');
        this.contextMenu = false;
        this.setColour(135);
    }
};

Blockly.Blocks['mutablecomponent_append_mutator_input'] = {
    init: function () {
        this.appendDummyInput().appendField(javabridge.t('blockly.mutablecomponent_append_mutator.input'));
        this.setPreviousStatement(true);
        this.setNextStatement(true);
        this.contextMenu = false;
        this.fieldValues_ = [];
        this.setColour(135);
    }
};

Blockly.Blocks['mutablecomponents_translatable_input'] = {
    init: function () {
        this.appendDummyInput().appendField(javabridge.t('blockly.translatable_component_mutator.input'));
        this.setPreviousStatement(true);
        this.setNextStatement(true);
        this.contextMenu = false;
        this.fieldValues_ = [];
        this.setColour(135);
    }
};
Blockly.Extensions.registerMutator('mutablecomponent_append_mutator', simpleRepeatingInputMixin(
        'mutablecomponent_append_mutator_container', 'mutablecomponent_append_mutator_input', 'mutablecomponents',
        function(thisBlock, inputName, index) {
            const ALIGN_RIGHT = Blockly.ALIGN_RIGHT ?? Blockly.Input.Align.RIGHT;
            thisBlock.appendValueInput(inputName + index).setCheck(["MutableComponent", "String"]).setAlign(ALIGN_RIGHT);
        }),
    undefined, ['mutablecomponent_append_mutator_input']);

Blockly.Extensions.registerMutator('mutablecomponent_bookbuild_mutator', simpleRepeatingInputMixin(
        'mutablecomponent_append_mutator_container', 'mutablecomponent_append_mutator_input', 'mutablecomponents',
        function(thisBlock, inputName, index) {
            const ALIGN_RIGHT = Blockly.ALIGN_RIGHT ?? Blockly.Input.Align.RIGHT;
            thisBlock.appendValueInput(inputName + index).setCheck("MutableComponent").setAlign(ALIGN_RIGHT);
        }),
    undefined, ['mutablecomponent_append_mutator_input']);

Blockly.Extensions.registerMutator('translatable_component_mutator', simpleRepeatingInputMixin(
        'mutablecomponents_translatable_container', 'mutablecomponents_translatable_input', 'translation_args',
        function(thisBlock, inputName, index) {
            const ALIGN_RIGHT = Blockly.ALIGN_RIGHT ?? Blockly.Input.Align.RIGHT;
            thisBlock.appendValueInput(inputName + index).setCheck(["String", "Number", "Boolean", "MutableComponent"]).
            setAlign(ALIGN_RIGHT).appendField("%" + (index + 1) + "$s:")
        }),
    undefined, ['mutablecomponents_translatable_input']);

Blockly.Extensions.register("translatable_arg_type_extension", function () {
  const colors = {
      Number: "%{BKY_MATH_HUE}",
      Boolean: "%{BKY_LOGIC_HUE}",
      String: "%{BKY_TEXTS_HUE}",
      MutableComponent: "%{BKY_COMPONENT_HUE}"
    }
  const update = () => {
    const value = this.getFieldValue("argtype");
    this.setColour(colors[value] ?? 135);
  };

  this.getField("argtype").setValidator(function (newValue) {
    const block = this.getSourceBlock();
    setTimeout(() => {
      block.setColour(colors[newValue] ?? 135);
    });
    return newValue;
  });

  update();
});